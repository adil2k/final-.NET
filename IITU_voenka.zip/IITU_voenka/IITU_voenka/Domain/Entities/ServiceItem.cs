﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace IITU_voenka.Domain.Entities
{
    public class ServiceItem : EntityBase
    {
        [Required(ErrorMessage = "Заполните название новости")]
        [Display(Name = "Название новости")]
        public override string Title { get; set; }

        [Required(ErrorMessage = "Заполните название новости")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Длина строки должна быть от 1 до 50 символов")]
        [Display(Name = "Краткое описание новости")]
        public override string Subtitle { get; set; }
        [Required(ErrorMessage = "Заполните название новости")]
        [StringLength(10000, MinimumLength = 10, ErrorMessage = "Длина строки должна быть от 10 до 10000 символов")]
        [Display(Name = "Полное описание новости")]
        public override string Text { get; set; }
    }
}
