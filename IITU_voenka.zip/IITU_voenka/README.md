# IITU_voenka
My project is a web application of the military department of IITU. There will be news, all the information about the military department, as well as everything about how to enter the military department.

models, controllers, CRUD, views, master page

database, tables, migrations, methods

authorization and authentication with asp.net Identity
